package heranca;

public class Estabalecimento {
    private int quantFuncionarios;
    private String balcaoDeAtendimento;
    private String moveis;

    public int getQuantFuncionarios() {
        return quantFuncionarios;
    }

    public void setQuantFuncionarios(int quantFuncionarios) {
        this.quantFuncionarios = quantFuncionarios;
    }

    public String getBalcaoDeAtendimento() {
        return balcaoDeAtendimento;
    }

    public void setBalcaoDeAtendimento(String balcaoDeAtendimento) {
        this.balcaoDeAtendimento = balcaoDeAtendimento;
    }

    public String getMoveis() {
        return moveis;
    }

    public void setMoveis(String moveis) {
        this.moveis = moveis;
    }
}

package heranca;

public class LojaDoces extends Estabalecimento {
    private String algodaoDoce;
    private String pipoca;
    private String suco;

    public String getAlgodaoDoce() {
        return algodaoDoce;
    }

    public void setAlgodaoDoce(String algodaoDoce) {
        this.algodaoDoce = algodaoDoce;
    }

    public String getPipoca() {
        return pipoca;
    }

    public void setPipoca(String pipoca) {
        this.pipoca = pipoca;
    }

    public String getSuco() {
        return suco;
    }

    public void setSuco(String suco) {
        this.suco = suco;
    }
}

package heranca;

public class LojaRoupa extends Estabalecimento{
    private String RoupaFenina;
    private String RoupaMasculina;
    private String RouInfantil;

    public String getRoupaFenina() {
        return RoupaFenina;
    }

    public void setRoupaFenina(String roupaFenina) {
        RoupaFenina = roupaFenina;
    }

    public String getRoupaMasculina() {
        return RoupaMasculina;
    }

    public void setRoupaMasculina(String roupaMasculina) {
        RoupaMasculina = roupaMasculina;
    }

    public String getRouInfantil() {
        return RouInfantil;
    }

    public void setRouInfantil(String rouInfantil) {
        RouInfantil = rouInfantil;
    }
}

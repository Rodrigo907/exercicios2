package polimorfismo;

public interface EstabelecimentoService {
    void imprimeInformcoes();

}

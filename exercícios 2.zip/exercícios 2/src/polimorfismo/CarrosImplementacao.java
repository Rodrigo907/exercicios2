package polimorfismo;

public class CarrosImplementacao implements EstabelecimentoService{
    @Override
    public void imprimeInformcoes() {
        System.out.println("Carro bacana");
    }
}

package polimorfismo;

public class RoupaImplementacao implements EstabelecimentoService{
    @Override
    public void imprimeInformcoes() {
        System.out.println("Roupa Da hora!");
    }
}
